// Bootstrap Tooltip
$(document).ready(function(){
	$("[data-toggle='tooltip']").tooltip();
});

// Price Range Slider
const range_input = $("#range");
const show_value = $(".price-range .price-rate-wrapper .left .rate-picker-wrapper .range label span.show-value");
const angle_range = $(".price-range .price-rate-wrapper .left .rate-picker-wrapper .rate-picker img.angle");


range_input.on('input', function(){
	// Set Value
	if ($(this).val() == 0){
		show_value.html("10 GB");
	}else if ($(this).val() == 12.5){
		show_value.html("20 GB");
	}else if ($(this).val() == 25){
		show_value.html("50 GB");
	}else if ($(this).val() == 37.5){
		show_value.html("100 GB");
	}else if ($(this).val() == 50){
		show_value.html("500 GB");
	}else if ($(this).val() == 62.5){
		show_value.html("1 TB");
	}else if ($(this).val() == 75){
		show_value.html("2 TB");
	}else if ($(this).val() == 87.5){
		show_value.html("5 TB");
	}else if ($(this).val() == 100){
		show_value.html("10 TB");
	};
	// Set Position of Value
	const value = range_input.val();
	const max = range_input.map(() => {return this.max}).get();
	const min = range_input.map(() => {return this.min}).get();
	const total_range = Number(max) - Number(min);
	const percent = (Number(value) - Number(min)) / total_range;

	if ($(this).val() == 100){
		show_value.css({
			left: `${(percent * 100)-20}%`
		})
	}else{
		show_value.css({
			left: `${(percent * 100)-5}%`
		})
	}
	// Rotate angle
	angle_range.css({
		transform: `rotate(${-170 + (percent * 180)}deg)`
	})

	
});

// Frequently Questions

$('.frequent-question .question').click(function(){
	$(this).toggleClass('active');
	$(this).siblings().slideToggle();
	$(this).children().toggleClass('fa-chevron-circle-down fa-chevron-circle-up');
});