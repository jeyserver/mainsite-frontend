import React from 'react'
import { Image } from 'react-bootstrap'

interface AdvantageProps {
  image: string
  imagePosition: 'left' | 'right'
  title: string
  description: string
}

const Advantage: React.FC<AdvantageProps> = ({
  image,
  imagePosition,
  title,
  description,
}) => {
  return (
    <React.Fragment>
      <div
        className={`d-flex justify-content-center align-items-center ${
          imagePosition === 'left'
            ? 'flex-column flex-lg-row'
            : 'flex-column flex-lg-row-reverse'
        }`}
      >
        <div className="wrapper img-wrapper">
          <Image src={image} alt="" />
        </div>
        <div
          className={`wrapper text-wrapper ${
            imagePosition === 'left' ? 'pl-80' : 'pr-80'
          }`}
        >
          <h2 className="font-bold font-24 mb-10 mt-20">{title}</h2>
          <p className="font-16 mb-10" dir="rtl">
            {description}
          </p>
        </div>
      </div>
    </React.Fragment>
  )
}

export default Advantage
