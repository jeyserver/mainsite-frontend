import { Dropdown, Image } from 'react-bootstrap'

const CountriesServers = () => {
  return (
    <div className="country-server d-flex flex-lg-row-reverse mx-auto">
      <a href="#" className="server-link bg-navy-blue text-white">
        <Image src="/img/Country flags/german.png" alt="" />
        <span className="text">سرورهای مجازی آلمان</span>
      </a>
      <a href="#" className="server-link bg-navy-blue text-white">
        <Image src="/img/Country flags/France.png" alt="" />
        <span className="text">سرورهای مجازی فرانسه</span>
      </a>
      <a href="#" className="server-link bg-navy-blue text-white">
        <Image src="/img/Country flags/iran.png" alt="" />
        <span className="text">سرورهای مجازی ایران</span>
      </a>
      <Dropdown
        style={{ padding: '0' }}
        className="server-link bg-navy-blue text-white dropdown"
      >
        <Dropdown.Toggle
          className="server-link dropdown-toggle"
          as="div"
          style={{
            width: '100%',
          }}
        >
          <Image src="/img/Country flags/other.png" alt="" />
          <span className="text">سایر کشورها</span>
          <span className="icon">
            <i className="fas fa-angle-down fa-lg"></i>
          </span>
        </Dropdown.Toggle>

        <Dropdown.Menu className="dropdown-menu">
          <Dropdown.Item
            eventKey="1"
            href="#"
            className="server-link dropdown-links-btn d-flex flex-row-reverse"
          >
            <Image src="/img/Country flags/finland.png" alt="" />
            <span className="text">پلن های فنلاند</span>
          </Dropdown.Item>
          <Dropdown.Item
            eventKey="2"
            href="#"
            className="server-link dropdown-links-btn d-flex flex-row-reverse"
          >
            <Image src="/img/Country flags/netherland.png" alt="" />
            <span className="text">پلن های هلند</span>
          </Dropdown.Item>
          <Dropdown.Item
            eventKey="3"
            href="#"
            className="server-link dropdown-links-btn d-flex flex-row-reverse"
          >
            <Image src="/img/Country flags/america.png" alt="" />
            <span className="text">پلن های آمریکا</span>
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
    </div>
  )
}

export default CountriesServers
