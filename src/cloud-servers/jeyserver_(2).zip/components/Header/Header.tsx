import { Button, Image } from 'react-bootstrap'

const Header = () => {
  return (
    <section className="main-header-wrapper">
      <div className="img-wave-background">
        <Image src="/img/top-left-wave.png" alt="" />
      </div>
      <div className="img-big-server">
        <Image src="/img/big-server.png" alt="" />
      </div>
      <div className="img-jet-cloud">
        <Image src="/img/jet.png" alt="" />
      </div>
      <div className="img-small-server">
        <Image src="/img/small-server.png" alt="" />
      </div>
      <div className="content mr-auto">
        <h1 className="font-bold-900 font-30 text-navy-blue">
          سرورهای ابری جی سرور
        </h1>
        <p className="font-16 mt-20" dir="rtl">
          این دسته از خدمات جدید جی سرور به شما این امکان را میدهد تا از بهترین
          مقرون به صرفه ترین دیتا سنتر های دیتا, پلن مورد نیاز خودتان را تهیه
          کنید و با استفاده از پلن مدیریتی فارسی و روان ما آنها را مدیریت کنید.
        </p>
        <div className="mt-20 mr-30">
          <Button href="#plans" className="bg-navy-blue font-16">
            مشاهده پلن ها
          </Button>
        </div>
      </div>
    </section>
  )
}

export default Header
