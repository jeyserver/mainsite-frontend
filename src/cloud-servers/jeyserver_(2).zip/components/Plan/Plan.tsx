import {
  Card,
  Col,
  Image,
  OverlayTrigger,
  Tooltip,
  Button,
} from 'react-bootstrap'

interface PlanProps {
  name: string
  monthly: string
  hourly: string
  cpu: number
  ram: number
  diskSpace: number
  traffic: number
  location: string
}

const Plan: React.FC<PlanProps> = ({
  name,
  monthly,
  hourly,
  cpu,
  ram,
  diskSpace,
  traffic,
  location,
}) => {
  return (
    <Col xs={12} sm={12} md={6} lg={3} xl={2} dir="rtl">
      <Card className="card">
        <Card.Header className="title bg-navy-blue text-center text-white">
          <h5>سرور مجازی {name}</h5>
        </Card.Header>
        <Card.Body className="card-content">
          <p className="month-price text-center mx-auto">
            <span className="text-orange">ماهیانه</span>/<span>{monthly}</span>{' '}
            تومان
          </p>
          <p className="hour-price">
            <span className="text-primary">ساعتی</span>/<span>{hourly}</span>{' '}
            تومان
          </p>
          <ul>
            <li>
              <span>CPU</span>
              <span>{cpu} core</span>
            </li>
            <li>
              <span>رم</span>
              <span>{ram} GB</span>
            </li>
            <li>
              <span>فضای دیسک</span>
              <span>{diskSpace} GB</span>
            </li>
            <li>
              <span>ترافیک</span>
              <span>{traffic} TB</span>
            </li>
            <li>
              <span>لوکیشن</span>
              <span>
                <OverlayTrigger
                  key="France"
                  overlay={<Tooltip id="tooltip-france">France</Tooltip>}
                >
                  <Image
                    src={location}
                    data-toggle="tooltip"
                    data-placement="top"
                    title="France"
                    alt=""
                  />
                </OverlayTrigger>
              </span>
            </li>
          </ul>
          {/* Tooltip was added to the country flag in the plans */}
          <div className="card-btn text-center">
            <Card.Link href="#" className="btn bg-orange text-white">
              <span className="icon">
                <i className="fas fa-shopping-cart" />
              </span>{' '}
              سفارش دهید
            </Card.Link>
          </div>
        </Card.Body>
      </Card>
    </Col>
  )
}

export default Plan
