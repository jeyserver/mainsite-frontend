import { Container, Col, Row, Nav, Tab } from 'react-bootstrap'
import Plan from '../Plan/Plan'

const Plans = () => {
  return (
    <Container fluid className="plans">
      {/* Title */}
      <div className="title text-center mt-30" dir="rtl">
        <p className="mb-10">پلن های پیش فرض اقتصادی ترند</p>
        <p className="mb-10">
          اگر بسته به نیازتان به cpu اختصاصی احتیاج دارید پلن های پیشرفته تر را
          نیز مشاهده نمایید
        </p>
      </div>
      <div className="plans-content mt-30">
        <Tab.Container defaultActiveKey="defaultPlans">
          {/* Plans Menu */}
          <Nav
            className="plans-menu flex-row-reverse justify-content-center"
            as="ul"
          >
            <Nav.Item as="li" dir="rtl">
              <Nav.Link eventKey="defaultPlans">پلن های پیشفرض</Nav.Link>
            </Nav.Item>
            <Nav.Item as="li" dir="rtl">
              <Nav.Link eventKey="specialCpu">CPU اختصاصی</Nav.Link>
            </Nav.Item>
          </Nav>
          <Tab.Content>
            {/* Default Plans */}
            <Tab.Pane eventKey="defaultPlans">
              <Row
                style={{
                  marginRight: '-15px',
                  marginLeft: '-15px',
                }}
                dir="rtl"
              >
                <Col xl={1}></Col>
                {Array(5)
                  .fill({
                    name: 'CX11',
                    monthly: '1,000,000',
                    hourly: '50,000',
                    cpu: 2,
                    ram: 2,
                    diskSpace: 40,
                    traffic: 20,
                    location: '/img/Country flags/France.png',
                  })
                  .map((plan, index) => (
                    <Plan
                      key={index}
                      name={plan.name}
                      monthly={plan.monthly}
                      hourly={plan.hourly}
                      cpu={plan.cpu}
                      ram={plan.ram}
                      diskSpace={plan.diskSpace}
                      traffic={plan.traffic}
                      location={plan.location}
                    />
                  ))}
              </Row>
            </Tab.Pane>
            {/* Special Cpu */}
            <Tab.Pane eventKey="specialCpu">
              <Row
                style={{
                  marginRight: '-15px',
                  marginLeft: '-15px',
                }}
                dir="rtl"
              >
                <Col xl={1}></Col>

                {Array(5)
                  .fill({
                    name: 'CX11',
                    monthly: '1,000,000',
                    hourly: '50,000',
                    cpu: 4,
                    ram: 2,
                    diskSpace: 40,
                    traffic: 20,
                    location: '/img/Country flags/France.png',
                  })
                  .map((plan, index) => (
                    <Plan
                      key={index}
                      name={plan.name}
                      monthly={plan.monthly}
                      hourly={plan.hourly}
                      cpu={plan.cpu}
                      ram={plan.ram}
                      diskSpace={plan.diskSpace}
                      traffic={plan.traffic}
                      location={plan.location}
                    />
                  ))}
              </Row>
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      </div>
    </Container>
  )
}

export default Plans
