import { useState } from 'react'
import { Accordion, Card } from 'react-bootstrap'

interface QuestionProps {
  index: number
  title: string
  answer: string
}

const Question: React.FC<QuestionProps> = ({ index, title, answer }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false)
  const showQuestion = () => {
    setIsOpen((isOpen) => !isOpen)
  }
  return (
    <Accordion>
      <Card className="question-wrapper">
        <Card.Header>
          <Accordion.Toggle
            className={`question font-16 ${isOpen ? 'active' : ''}`}
            as="div"
            eventKey={`${index}`}
            dir="rtl"
            onClick={showQuestion}
          >
            {title}
            <i
              className={`${
                isOpen
                  ? 'fas fa-chevron-circle-down fa-chevron-circle-up fa-lg'
                  : 'fas fa-chevron-circle-down fa-lg'
              }`}
            />
          </Accordion.Toggle>
          <Accordion.Collapse eventKey={`${index}`}>
            <Card.Body>
              <p>{answer}</p>
            </Card.Body>
          </Accordion.Collapse>
        </Card.Header>
      </Card>
    </Accordion>
  )
}

export default Question
