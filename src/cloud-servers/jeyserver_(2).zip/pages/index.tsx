import React from 'react'
import Head from 'next/head'
import Header from '../components/Header/Header'
import Advantage from '../components/Advantage/Advantage'
import CountriesServers from '../components/CountriesServers/CountriesServers'
import { InferGetStaticPropsType } from 'next'
import getAllAdvantages, { advantagesType } from '../lib/advantages'
import Plans from '../components/Plans/Plans'
import Price from '../components/Price/Price'
import Faq from '../components/Faq/Faq'

export default function Home({
  advantages,
}: InferGetStaticPropsType<typeof getStaticProps>) {
  return (
    <React.Fragment>
      <Head>
        <title>Jey Server</title>
        <link rel="icon" href="/favicon.ico" />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
        ></link>
      </Head>
      {/* Main Header */}
      <Header />
      {/* Advantages */}
      <div className="advantages">
        {advantages.map((advantage) => (
          <Advantage
            key={advantage.id}
            image={advantage.image}
            imagePosition={advantage.imagePosition}
            title={advantage.title}
            description={advantage.description}
          />
        ))}
      </div>
      {/* Servers of different countries */}
      <CountriesServers />
      {/* Plans */}
      <Plans />
      {/* Price Range */}
      <Price />
      {/* Freequently Questions */}
      <Faq />
    </React.Fragment>
  )
}

export const getStaticProps = async () => {
  const advantages: advantagesType = getAllAdvantages()

  return {
    props: {
      advantages: advantages,
    },
  }
}
